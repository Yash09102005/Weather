# Quick Start Guide

## Step 1: Prepare MySQL Database

Open MySQL and run:
```sql
CREATE DATABASE weather;
```

## Step 2: Update Database Credentials

Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD_HERE
```

## Step 3: Run the Application

Open terminal in the project folder and run:
```bash
mvnw.cmd spring-boot:run
```

Wait for the message: "Started WeatherApplication"

## Step 4: Test the API

Open your browser or use a tool like Postman/curl.

### Test Basic Filter
```
http://localhost:8080/api/weather/filter?year=2010&month=1
```

### Test Advanced Filter (NEW)
```
http://localhost:8080/api/weather/filter/advanced?minTemperature=20&maxTemperature=30&year=2015
```

### Test Monthly Stats
```
http://localhost:8080/api/weather/stats?year=2013
```

### Test Aggregation
```
http://localhost:8080/api/weather/aggregate?groupBy=month&year=2012
```

## Common Issues

**Red markings in IDE?**
- Run: `mvnw.cmd clean compile`
- Refresh your IDE project

**Database connection error?**
- Check MySQL is running
- Verify username/password in application.properties
- Ensure database "weather" exists

**No data returned?**
- Check if data file exists: `src/main/resources/data/testset.xlsx` or `testset.csv`
- Check console logs for data loading messages

## Using Browser

Simply paste the URLs above into your browser address bar. You'll see JSON responses.

## Using curl (Command Line)

```bash
curl "http://localhost:8080/api/weather/filter?year=2010"

curl "http://localhost:8080/api/weather/filter/advanced?minTemperature=25&rain=true"

curl "http://localhost:8080/api/weather/stats?year=2013"
```

## Stop the Application

Press `Ctrl + C` in the terminal where the app is running.
