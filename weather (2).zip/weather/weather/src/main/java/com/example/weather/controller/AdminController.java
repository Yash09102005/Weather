package com.example.weather.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.weather.prerun.DataLoader;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final DataLoader dataLoader;

    public AdminController(DataLoader dataLoader) {
        this.dataLoader = dataLoader;
    }

    @PostMapping("/reload-data")
    public String reloadData() {
        dataLoader.loadData();
        return "Data reload triggered. Check console for details.";
    }
}
