package com.example.weather.prerun;

import java.io.InputStreamReader;
import java.util.List;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

@Component
public class CsvReader {

    public List<String[]> read(String fileName) throws Exception {
        ClassPathResource resource = new ClassPathResource("data/" + fileName);
        if (!resource.exists()) {
            throw new Exception("File not found: " + fileName);
        }

        try (CSVReader reader = new CSVReaderBuilder(new InputStreamReader(resource.getInputStream()))
                .build()) {
            return reader.readAll();
        }
    }
}
