package com.example.weather.prerun;

import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.weather.entity.WeatherEntity;
import com.example.weather.repository.WeatherRepository;

@Component
public class DataLoader implements CommandLineRunner {

    private final ExcelReader excelReader;
    private final CsvReader csvReader;
    private final WeatherTransformer transformer;
    private final WeatherRepository repository;

    public DataLoader(ExcelReader excelReader,
            CsvReader csvReader,
            WeatherTransformer transformer,
            WeatherRepository repository) {
        this.excelReader = excelReader;
        this.csvReader = csvReader;
        this.transformer = transformer;
        this.repository = repository;
    }

    @Override
    public void run(String... args) throws Exception {
        loadData();
    }

    public void loadData() {
        if (repository.count() > 0) {
            System.out.println(
                    "Weather data already exists in database (" + repository.count() + " records). Skipping load.");
            return;
        }

        System.out.println("Starting weather data load...");

        // Try CSV first as per requirement
        boolean loaded = tryLoadCsv("testset.csv");

        if (!loaded) {
            // Fallback to Excel
            tryLoadExcel("testset.xlsx");
        }
    }

    private boolean tryLoadCsv(String fileName) {
        try {
            System.out.println("Attempting to load from CSV: " + fileName);
            List<String[]> lines = csvReader.read(fileName);
            int successCount = 0;
            for (String[] line : lines) {
                WeatherEntity entity = transformer.transform(line);
                if (entity != null) {
                    repository.save(entity);
                    successCount++;
                }
            }
            System.out.println("CSV load completed. Records: " + successCount);
            return successCount > 0;
        } catch (Exception e) {
            System.out.println("CSV load skipped or failed: " + e.getMessage());
            return false;
        }
    }

    private boolean tryLoadExcel(String fileName) {
        try {
            System.out.println("Attempting to load from Excel: " + fileName);
            List<Row> rows = excelReader.read(fileName);
            int successCount = 0;
            for (int i = 1; i < rows.size(); i++) {
                WeatherEntity entity = transformer.transform(rows.get(i));
                if (entity != null) {
                    repository.save(entity);
                    successCount++;
                }
            }
            System.out.println("Excel load completed. Records: " + successCount);
            return successCount > 0;
        } catch (Exception e) {
            System.out.println("Excel load skipped or failed: " + e.getMessage());
            return false;
        }
    }
}