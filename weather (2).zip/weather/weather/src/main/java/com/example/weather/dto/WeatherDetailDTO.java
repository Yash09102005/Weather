package com.example.weather.dto;

import java.time.LocalDate;

public class WeatherDetailDTO {
    private LocalDate recordDate;
    private String weatherCondition;
    private Double temperature;
    private Integer humidity;
    private Double pressure;

    public WeatherDetailDTO() {
    }

    public WeatherDetailDTO(LocalDate recordDate, String weatherCondition, Double temperature, Integer humidity,
            Double pressure) {
        this.recordDate = recordDate;
        this.weatherCondition = weatherCondition;
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
    }

    public LocalDate getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(LocalDate recordDate) {
        this.recordDate = recordDate;
    }

    public String getWeatherCondition() {
        return weatherCondition;
    }

    public void setWeatherCondition(String weatherCondition) {
        this.weatherCondition = weatherCondition;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Integer getHumidity() {
        return humidity;
    }

    public void setHumidity(Integer humidity) {
        this.humidity = humidity;
    }

    public Double getPressure() {
        return pressure;
    }

    public void setPressure(Double pressure) {
        this.pressure = pressure;
    }
}
