package com.example.weather.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "weather_data")
public class WeatherEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate recordDate;
    private Integer year;
    private Integer month;
    private Integer day;

    private Double temperature;
    private Integer humidity;
    private Double pressure;
    private Double heatIndex;
    private Double dewPoint;

    private Double precipitation;
    private Double visibility;

    private Double windSpeed;
    private Double windGust;
    private Double windChill;
    private Integer windDirDeg;
    private String windDirText;

    private Boolean fog;
    private Boolean rain;
    private Boolean snow;
    private Boolean thunder;
    private Boolean tornado;

    private String weatherCondition;

    public WeatherEntity() {
    }

    public WeatherEntity(Long id, LocalDate recordDate, Integer year, Integer month, Integer day,
            Double temperature, Integer humidity, Double pressure, Double heatIndex, Double dewPoint,
            Double precipitation, Double visibility, Double windSpeed, Double windGust, Double windChill,
            Integer windDirDeg, String windDirText, Boolean fog, Boolean rain, Boolean snow,
            Boolean thunder, Boolean tornado, String weatherCondition) {
        this.id = id;
        this.recordDate = recordDate;
        this.year = year;
        this.month = month;
        this.day = day;
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
        this.heatIndex = heatIndex;
        this.dewPoint = dewPoint;
        this.precipitation = precipitation;
        this.visibility = visibility;
        this.windSpeed = windSpeed;
        this.windGust = windGust;
        this.windChill = windChill;
        this.windDirDeg = windDirDeg;
        this.windDirText = windDirText;
        this.fog = fog;
        this.rain = rain;
        this.snow = snow;
        this.thunder = thunder;
        this.tornado = tornado;
        this.weatherCondition = weatherCondition;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(LocalDate recordDate) {
		this.recordDate = recordDate;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}

	public Double getTemperature() {
		return temperature;
	}

	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}

	public Integer getHumidity() {
		return humidity;
	}

	public void setHumidity(Integer humidity) {
		this.humidity = humidity;
	}

	public Double getPressure() {
		return pressure;
	}

	public void setPressure(Double pressure) {
		this.pressure = pressure;
	}

	public Double getHeatIndex() {
		return heatIndex;
	}

	public void setHeatIndex(Double heatIndex) {
		this.heatIndex = heatIndex;
	}

	public Double getDewPoint() {
		return dewPoint;
	}

	public void setDewPoint(Double dewPoint) {
		this.dewPoint = dewPoint;
	}

	public Double getPrecipitation() {
		return precipitation;
	}

	public void setPrecipitation(Double precipitation) {
		this.precipitation = precipitation;
	}

	public Double getVisibility() {
		return visibility;
	}

	public void setVisibility(Double visibility) {
		this.visibility = visibility;
	}

	public Double getWindSpeed() {
		return windSpeed;
	}

	public void setWindSpeed(Double windSpeed) {
		this.windSpeed = windSpeed;
	}

	public Double getWindGust() {
		return windGust;
	}

	public void setWindGust(Double windGust) {
		this.windGust = windGust;
	}

	public Double getWindChill() {
		return windChill;
	}

	public void setWindChill(Double windChill) {
		this.windChill = windChill;
	}

	public Integer getWindDirDeg() {
		return windDirDeg;
	}

	public void setWindDirDeg(Integer windDirDeg) {
		this.windDirDeg = windDirDeg;
	}

	public String getWindDirText() {
		return windDirText;
	}

	public void setWindDirText(String windDirText) {
		this.windDirText = windDirText;
	}

	public Boolean getFog() {
		return fog;
	}

	public void setFog(Boolean fog) {
		this.fog = fog;
	}

	public Boolean getRain() {
		return rain;
	}

	public void setRain(Boolean rain) {
		this.rain = rain;
	}

	public Boolean getSnow() {
		return snow;
	}

	public void setSnow(Boolean snow) {
		this.snow = snow;
	}

	public Boolean getThunder() {
		return thunder;
	}

	public void setThunder(Boolean thunder) {
		this.thunder = thunder;
	}

	public Boolean getTornado() {
		return tornado;
	}

	public void setTornado(Boolean tornado) {
		this.tornado = tornado;
	}

	public String getWeatherCondition() {
		return weatherCondition;
	}

	public void setWeatherCondition(String weatherCondition) {
		this.weatherCondition = weatherCondition;
	}

}
