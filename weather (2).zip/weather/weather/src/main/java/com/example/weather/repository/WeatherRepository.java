package com.example.weather.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.example.weather.entity.WeatherEntity;

public interface WeatherRepository
extends JpaRepository<WeatherEntity, Long>,
        JpaSpecificationExecutor<WeatherEntity> {
}