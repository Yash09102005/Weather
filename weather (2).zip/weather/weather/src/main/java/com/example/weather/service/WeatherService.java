package com.example.weather.service;

import java.time.LocalDate;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.example.weather.dto.MonthlyStatsDTO;
import com.example.weather.dto.WeatherDetailDTO;
import com.example.weather.dto.WeatherFilterDTO;
import com.example.weather.dto.WeatherSummaryDTO;
import com.example.weather.entity.WeatherEntity;
import com.example.weather.repository.WeatherRepository;
import com.example.weather.spec.WeatherSpecification;

@Service
public class WeatherService {

    private final WeatherRepository repository;

    public WeatherService(WeatherRepository repository) {
        this.repository = repository;
    }

    public List<WeatherDetailDTO> filterWeather(
            String condition,
            LocalDate date,
            Integer month,
            Integer year) {

        Specification<WeatherEntity> spec = buildSpecification(
                WeatherSpecification.hasCondition(condition),
                WeatherSpecification.hasDate(date),
                WeatherSpecification.hasMonth(month),
                WeatherSpecification.hasYear(year));

        return repository.findAll(spec).stream()
                .map(this::mapToDetailDTO)
                .collect(Collectors.toList());
    }

    public List<WeatherDetailDTO> advancedFilter(WeatherFilterDTO filter) {
        Specification<WeatherEntity> spec = buildSpecification(
                WeatherSpecification.hasCondition(filter.getCondition()),
                WeatherSpecification.hasDateBetween(filter.getStartDate(), filter.getEndDate()),
                WeatherSpecification.hasYear(filter.getYear()),
                WeatherSpecification.hasMonth(filter.getMonth()),
                WeatherSpecification.hasTemperatureBetween(filter.getMinTemperature(), filter.getMaxTemperature()),
                WeatherSpecification.hasHumidityBetween(filter.getMinHumidity(), filter.getMaxHumidity()),
                WeatherSpecification.hasFog(filter.getFog()),
                WeatherSpecification.hasRain(filter.getRain()),
                WeatherSpecification.hasSnow(filter.getSnow()),
                WeatherSpecification.hasThunder(filter.getThunder()));

        return repository.findAll(spec).stream()
                .map(this::mapToDetailDTO)
                .collect(Collectors.toList());
    }

    public List<MonthlyStatsDTO> getMonthlyStats(int year) {
        List<WeatherEntity> yearData = repository.findAll(WeatherSpecification.hasYear(year));

        Map<Integer, List<WeatherEntity>> dataByMonth = yearData.stream()
                .filter(e -> e.getMonth() != null)
                .collect(Collectors.groupingBy(WeatherEntity::getMonth, TreeMap::new, Collectors.toList()));

        return dataByMonth.entrySet().stream()
                .map(entry -> calculateMonthlyStats(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
    }

    public Map<String, WeatherSummaryDTO> getAggregatedStats(
            String groupBy,
            String condition,
            Integer year,
            Integer month) {

        Specification<WeatherEntity> spec = buildSpecification(
                WeatherSpecification.hasCondition(condition),
                WeatherSpecification.hasYear(year),
                WeatherSpecification.hasMonth(month));

        List<WeatherEntity> data = repository.findAll(spec);
        Map<String, List<WeatherEntity>> grouped = groupData(data, groupBy);

        return grouped.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> calculateSummary(entry.getValue()),
                        (oldV, newV) -> oldV,
                        TreeMap::new));
    }

    @SafeVarargs
    private final Specification<WeatherEntity> buildSpecification(Specification<WeatherEntity>... specs) {
        Specification<WeatherEntity> result = null;
        for (Specification<WeatherEntity> spec : specs) {
            if (spec != null) {
                result = result == null ? spec : result.and(spec);
            }
        }
        return result;
    }

    private WeatherDetailDTO mapToDetailDTO(WeatherEntity entity) {
        return new WeatherDetailDTO(
                entity.getRecordDate(),
                entity.getWeatherCondition(),
                entity.getTemperature(),
                entity.getHumidity(),
                entity.getPressure());
    }

    private MonthlyStatsDTO calculateMonthlyStats(Integer month, List<WeatherEntity> entities) {
        List<Double> temps = entities.stream()
                .map(WeatherEntity::getTemperature)
                .filter(t -> t != null)
                .sorted()
                .collect(Collectors.toList());

        if (temps.isEmpty()) {
            return new MonthlyStatsDTO(month, null, null, null);
        }

        Double min = temps.get(0);
        Double max = temps.get(temps.size() - 1);
        Double median = calculateMedian(temps);

        return new MonthlyStatsDTO(month, max, min, median);
    }

    private Double calculateMedian(List<Double> sortedValues) {
        int size = sortedValues.size();
        if (size % 2 == 0) {
            return (sortedValues.get(size / 2 - 1) + sortedValues.get(size / 2)) / 2;
        }
        return sortedValues.get(size / 2);
    }

    private Map<String, List<WeatherEntity>> groupData(List<WeatherEntity> data, String groupBy) {
        switch (groupBy.toLowerCase()) {
            case "year":
                return data.stream()
                        .filter(e -> e.getYear() != null)
                        .collect(Collectors.groupingBy(e -> e.getYear().toString(), TreeMap::new, Collectors.toList()));
            case "month":
                return data.stream()
                        .filter(e -> e.getMonth() != null)
                        .collect(Collectors.groupingBy(e -> e.getMonth().toString(), TreeMap::new, Collectors.toList()));
            case "condition":
                return data.stream()
                        .filter(e -> e.getWeatherCondition() != null)
                        .collect(Collectors.groupingBy(WeatherEntity::getWeatherCondition, TreeMap::new, Collectors.toList()));
            case "day":
                return data.stream()
                        .filter(e -> e.getRecordDate() != null)
                        .collect(Collectors.groupingBy(e -> e.getRecordDate().toString(), TreeMap::new, Collectors.toList()));
            default:
                throw new IllegalArgumentException(
                        "Invalid groupBy option: " + groupBy + ". Use year, month, day, or condition.");
        }
    }

    private WeatherSummaryDTO calculateSummary(List<WeatherEntity> entities) {
        DoubleSummaryStatistics tempStats = entities.stream()
                .map(WeatherEntity::getTemperature)
                .filter(t -> t != null)
                .mapToDouble(Double::doubleValue)
                .summaryStatistics();

        Double avgHumidity = entities.stream()
                .map(WeatherEntity::getHumidity)
                .filter(h -> h != null)
                .mapToInt(Integer::intValue)
                .average()
                .orElse(0.0);

        return new WeatherSummaryDTO(
                tempStats.getMin() == Double.POSITIVE_INFINITY ? null : tempStats.getMin(),
                tempStats.getMax() == Double.NEGATIVE_INFINITY ? null : tempStats.getMax(),
                tempStats.getAverage(),
                avgHumidity,
                tempStats.getCount());
    }
}
