package com.example.weather.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.weather.dto.MonthlyStatsDTO;
import com.example.weather.dto.WeatherDetailDTO;
import com.example.weather.dto.WeatherFilterDTO;
import com.example.weather.dto.WeatherSummaryDTO;
import com.example.weather.service.WeatherService;

@RestController
@RequestMapping("/api/weather")
public class WeatherController {

    private final WeatherService service;

    public WeatherController(WeatherService service) {
        this.service = service;
    }

    @GetMapping("/filter")
    public List<WeatherDetailDTO> filterWeather(
            @RequestParam(required = false) String condition,
            @RequestParam(required = false) LocalDate date,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Integer year) {

        return service.filterWeather(condition, date, month, year);
    }

    @GetMapping("/filter/advanced")
    public List<WeatherDetailDTO> advancedFilter(
            @RequestParam(required = false) String condition,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate,
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month,
            @RequestParam(required = false) Double minTemperature,
            @RequestParam(required = false) Double maxTemperature,
            @RequestParam(required = false) Integer minHumidity,
            @RequestParam(required = false) Integer maxHumidity,
            @RequestParam(required = false) Boolean fog,
            @RequestParam(required = false) Boolean rain,
            @RequestParam(required = false) Boolean snow,
            @RequestParam(required = false) Boolean thunder) {

        WeatherFilterDTO filter = new WeatherFilterDTO();
        filter.setCondition(condition);
        filter.setStartDate(startDate);
        filter.setEndDate(endDate);
        filter.setYear(year);
        filter.setMonth(month);
        filter.setMinTemperature(minTemperature);
        filter.setMaxTemperature(maxTemperature);
        filter.setMinHumidity(minHumidity);
        filter.setMaxHumidity(maxHumidity);
        filter.setFog(fog);
        filter.setRain(rain);
        filter.setSnow(snow);
        filter.setThunder(thunder);

        return service.advancedFilter(filter);
    }

    @GetMapping("/stats")
    public List<MonthlyStatsDTO> getMonthlyStats(@RequestParam int year) {
        return service.getMonthlyStats(year);
    }

    @GetMapping("/aggregate")
    public Map<String, WeatherSummaryDTO> getAggregatedStats(
            @RequestParam(defaultValue = "year") String groupBy,
            @RequestParam(required = false) String condition,
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month) {

        return service.getAggregatedStats(groupBy, condition, year, month);
    }
}
