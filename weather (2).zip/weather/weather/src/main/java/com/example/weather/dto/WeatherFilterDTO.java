package com.example.weather.dto;

import java.time.LocalDate;

public class WeatherFilterDTO {
    private String condition;
    private LocalDate startDate;
    private LocalDate endDate;
    private Integer year;
    private Integer month;
    private Double minTemperature;
    private Double maxTemperature;
    private Integer minHumidity;
    private Integer maxHumidity;
    private Boolean fog;
    private Boolean rain;
    private Boolean snow;
    private Boolean thunder;

    public WeatherFilterDTO() {
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Double getMinTemperature() {
        return minTemperature;
    }

    public void setMinTemperature(Double minTemperature) {
        this.minTemperature = minTemperature;
    }

    public Double getMaxTemperature() {
        return maxTemperature;
    }

    public void setMaxTemperature(Double maxTemperature) {
        this.maxTemperature = maxTemperature;
    }

    public Integer getMinHumidity() {
        return minHumidity;
    }

    public void setMinHumidity(Integer minHumidity) {
        this.minHumidity = minHumidity;
    }

    public Integer getMaxHumidity() {
        return maxHumidity;
    }

    public void setMaxHumidity(Integer maxHumidity) {
        this.maxHumidity = maxHumidity;
    }

    public Boolean getFog() {
        return fog;
    }

    public void setFog(Boolean fog) {
        this.fog = fog;
    }

    public Boolean getRain() {
        return rain;
    }

    public void setRain(Boolean rain) {
        this.rain = rain;
    }

    public Boolean getSnow() {
        return snow;
    }

    public void setSnow(Boolean snow) {
        this.snow = snow;
    }

    public Boolean getThunder() {
        return thunder;
    }

    public void setThunder(Boolean thunder) {
        this.thunder = thunder;
    }
}
