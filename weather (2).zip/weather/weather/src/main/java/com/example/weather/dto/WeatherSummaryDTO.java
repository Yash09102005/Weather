package com.example.weather.dto;

public class WeatherSummaryDTO {
    private Double minTemp;
    private Double maxTemp;
    private Double avgTemp;
    private Double avgHumidity;
    private Long count;

    public WeatherSummaryDTO() {
    }

    public WeatherSummaryDTO(Double minTemp, Double maxTemp, Double avgTemp, Double avgHumidity, Long count) {
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.avgTemp = avgTemp;
        this.avgHumidity = avgHumidity;
        this.count = count;
    }

    public Double getMinTemp() {
        return minTemp;
    }

    public void setMinTemp(Double minTemp) {
        this.minTemp = minTemp;
    }

    public Double getMaxTemp() {
        return maxTemp;
    }

    public void setMaxTemp(Double maxTemp) {
        this.maxTemp = maxTemp;
    }

    public Double getAvgTemp() {
        return avgTemp;
    }

    public void setAvgTemp(Double avgTemp) {
        this.avgTemp = avgTemp;
    }

    public Double getAvgHumidity() {
        return avgHumidity;
    }

    public void setAvgHumidity(Double avgHumidity) {
        this.avgHumidity = avgHumidity;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }
}
