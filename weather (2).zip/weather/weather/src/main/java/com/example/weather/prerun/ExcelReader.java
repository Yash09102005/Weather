package com.example.weather.prerun;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
public class ExcelReader {

    public List<Row> read(String fileName) throws Exception {

        ClassPathResource resource =
                new ClassPathResource("data/" + fileName);

        InputStream is = resource.getInputStream();
        Workbook workbook = WorkbookFactory.create(is);

        Sheet sheet = workbook.getSheetAt(0);

        List<Row> rows = new ArrayList<>();
        sheet.forEach(rows::add);

        workbook.close();
        return rows;
    }
}