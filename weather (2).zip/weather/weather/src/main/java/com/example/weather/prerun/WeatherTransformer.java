package com.example.weather.prerun;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.stereotype.Component;

import com.example.weather.entity.WeatherEntity;

@Component
public class WeatherTransformer {

    private static final DateTimeFormatter[] DATE_FORMATTERS = {
            DateTimeFormatter.ofPattern("yyyyMMdd-HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd")
    };

    public WeatherEntity transform(Row row) {
        if (row.getRowNum() == 0)
            return null;

        WeatherEntity w = new WeatherEntity();
        LocalDate date = getDateFromCell(row.getCell(0));
        populateData(w, date,
                getStringFromCell(row.getCell(1)),
                getDoubleFromCell(row.getCell(2)),
                getBoolFromCell(row.getCell(3)),
                getDoubleFromCell(row.getCell(5)),
                getIntFromCell(row.getCell(6)),
                getDoubleFromCell(row.getCell(8)),
                getBoolFromCell(row.getCell(9)),
                getBoolFromCell(row.getCell(10)),
                getDoubleFromCell(row.getCell(11)),
                getBoolFromCell(row.getCell(12)),
                getBoolFromCell(row.getCell(13)),
                getDoubleFromCell(row.getCell(14)),
                getIntFromCell(row.getCell(15)),
                getStringFromCell(row.getCell(16)),
                getDoubleFromCell(row.getCell(17)),
                getDoubleFromCell(row.getCell(18)),
                getDoubleFromCell(row.getCell(19)));
        return w;
    }

    public WeatherEntity transform(String[] data) {
        if (data == null || data.length < 20)
            return null;
        if (data[0].equalsIgnoreCase("datetime_utc"))
            return null; // header

        WeatherEntity w = new WeatherEntity();
        LocalDate date = parseDate(data[0]);
        populateData(w, date,
                data[1],
                parseSafeDouble(data[2]),
                parseSafeBool(data[3]),
                parseSafeDouble(data[5]),
                parseSafeInt(data[6]),
                parseSafeDouble(data[8]),
                parseSafeBool(data[9]),
                parseSafeBool(data[10]),
                parseSafeDouble(data[11]),
                parseSafeBool(data[12]),
                parseSafeBool(data[13]),
                parseSafeDouble(data[14]),
                parseSafeInt(data[15]),
                data[16],
                parseSafeDouble(data[17]),
                parseSafeDouble(data[18]),
                parseSafeDouble(data[19]));
        return w;
    }

    private void populateData(WeatherEntity w, LocalDate date, String condition, Double dewPoint, Boolean fog,
            Double heatIndex, Integer humidity, Double pressure, Boolean rain, Boolean snow,
            Double temp, Boolean thunder, Boolean tornado, Double visibility, Integer windDeg,
            String windText, Double windGust, Double windChill, Double windSpeed) {
        w.setRecordDate(date);
        if (date != null) {
            w.setYear(date.getYear());
            w.setMonth(date.getMonthValue());
            w.setDay(date.getDayOfMonth());
        }
        w.setWeatherCondition(condition);
        w.setDewPoint(dewPoint);
        w.setFog(fog);
        w.setHeatIndex(heatIndex);
        w.setHumidity(humidity);
        w.setPressure(pressure);
        w.setRain(rain);
        w.setSnow(snow);
        w.setTemperature(temp);
        w.setThunder(thunder);
        w.setTornado(tornado);
        w.setVisibility(visibility);
        w.setWindDirDeg(windDeg);
        w.setWindDirText(windText);
        w.setWindGust(windGust);
        w.setWindChill(windChill);
        w.setWindSpeed(windSpeed);
    }

    // ---------------- HELPER METHODS ----------------

    private LocalDate getDateFromCell(Cell cell) {
        if (cell == null)
            return null;
        if (cell.getCellType() == CellType.STRING) {
            return parseDate(cell.getStringCellValue());
        }
        if (cell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(cell)) {
            Date d = cell.getDateCellValue();
            return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        }
        return null;
    }

    private LocalDate parseDate(String val) {
        if (val == null || val.trim().isEmpty())
            return null;
        for (DateTimeFormatter fmt : DATE_FORMATTERS) {
            try {
                if (val.contains("-") && val.contains(":")) {
                    return LocalDateTime.parse(val.trim(), fmt).toLocalDate();
                } else {
                    return LocalDate.parse(val.trim(), fmt);
                }
            } catch (Exception ignored) {
            }
        }
        System.out.println("❌ FAILED TO PARSE DATE: " + val);
        return null;
    }

    private Double getDoubleFromCell(Cell cell) {
        if (cell == null || cell.getCellType() != CellType.NUMERIC)
            return null;
        double v = cell.getNumericCellValue();
        return v == -9999 ? null : v;
    }

    private Integer getIntFromCell(Cell cell) {
        Double d = getDoubleFromCell(cell);
        return d == null ? null : d.intValue();
    }

    private Boolean getBoolFromCell(Cell cell) {
        Double d = getDoubleFromCell(cell);
        return d == null ? null : d == 1.0;
    }

    private String getStringFromCell(Cell cell) {
        if (cell == null)
            return null;
        String s = cell.toString().trim();
        return s.isEmpty() ? null : s;
    }

    private Double parseSafeDouble(String s) {
        try {
            return Double.parseDouble(s);
        } catch (Exception e) {
            return null;
        }
    }

    private Integer parseSafeInt(String s) {
        try {
            return (int) Double.parseDouble(s);
        } catch (Exception e) {
            return null;
        }
    }

    private Boolean parseSafeBool(String s) {
        try {
            return Double.parseDouble(s) == 1.0;
        } catch (Exception e) {
            return false;
        }
    }
}