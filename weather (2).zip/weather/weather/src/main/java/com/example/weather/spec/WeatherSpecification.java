package com.example.weather.spec;

import java.time.LocalDate;

import org.springframework.data.jpa.domain.Specification;

import com.example.weather.entity.WeatherEntity;

public class WeatherSpecification {

    public static Specification<WeatherEntity> hasCondition(String condition) {
        return (root, query, cb) -> condition == null || condition.trim().isEmpty() ? null
                : cb.equal(
                        cb.lower(cb.trim(root.get("weatherCondition"))),
                        condition.trim().toLowerCase());
    }

    public static Specification<WeatherEntity> hasDate(LocalDate date) {
        return (root, query, cb) -> date == null ? null : cb.equal(root.get("recordDate"), date);
    }

    public static Specification<WeatherEntity> hasDateBetween(LocalDate startDate, LocalDate endDate) {
        return (root, query, cb) -> {
            if (startDate == null && endDate == null) return null;
            if (startDate != null && endDate != null) {
                return cb.between(root.get("recordDate"), startDate, endDate);
            }
            if (startDate != null) {
                return cb.greaterThanOrEqualTo(root.get("recordDate"), startDate);
            }
            return cb.lessThanOrEqualTo(root.get("recordDate"), endDate);
        };
    }

    public static Specification<WeatherEntity> hasMonth(Integer month) {
        return (root, query, cb) -> month == null ? null : cb.equal(root.get("month"), month);
    }

    public static Specification<WeatherEntity> hasYear(Integer year) {
        return (root, query, cb) -> year == null ? null : cb.equal(root.get("year"), year);
    }

    public static Specification<WeatherEntity> hasTemperatureBetween(Double minTemp, Double maxTemp) {
        return (root, query, cb) -> {
            if (minTemp == null && maxTemp == null) return null;
            if (minTemp != null && maxTemp != null) {
                return cb.between(root.get("temperature"), minTemp, maxTemp);
            }
            if (minTemp != null) {
                return cb.greaterThanOrEqualTo(root.get("temperature"), minTemp);
            }
            return cb.lessThanOrEqualTo(root.get("temperature"), maxTemp);
        };
    }

    public static Specification<WeatherEntity> hasHumidityBetween(Integer minHumidity, Integer maxHumidity) {
        return (root, query, cb) -> {
            if (minHumidity == null && maxHumidity == null) return null;
            if (minHumidity != null && maxHumidity != null) {
                return cb.between(root.get("humidity"), minHumidity, maxHumidity);
            }
            if (minHumidity != null) {
                return cb.greaterThanOrEqualTo(root.get("humidity"), minHumidity);
            }
            return cb.lessThanOrEqualTo(root.get("humidity"), maxHumidity);
        };
    }

    public static Specification<WeatherEntity> hasFog(Boolean fog) {
        return (root, query, cb) -> fog == null ? null : cb.equal(root.get("fog"), fog);
    }

    public static Specification<WeatherEntity> hasRain(Boolean rain) {
        return (root, query, cb) -> rain == null ? null : cb.equal(root.get("rain"), rain);
    }

    public static Specification<WeatherEntity> hasSnow(Boolean snow) {
        return (root, query, cb) -> snow == null ? null : cb.equal(root.get("snow"), snow);
    }

    public static Specification<WeatherEntity> hasThunder(Boolean thunder) {
        return (root, query, cb) -> thunder == null ? null : cb.equal(root.get("thunder"), thunder);
    }
}
