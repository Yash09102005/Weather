# Weather Data API

A Spring Boot REST API for analyzing historical weather data. Query 20 years of weather records with flexible filtering, statistics, and aggregation options.

## What It Does

This API lets you explore weather data through several endpoints:

- Filter records by date, condition, temperature, humidity, and weather events
- Get monthly temperature statistics (high, low, median)
- Aggregate data by year, month, day, or weather condition
- Reload data without restarting the server

## Tech Stack

- Java 17
- Spring Boot 3.x
- MySQL with JPA
- Apache POI (Excel parsing)
- OpenCSV (CSV parsing)

## Setup

### Prerequisites

- Java 17 or higher
- MySQL running locally
- Maven (or use included wrapper)

### Steps

1. Create a MySQL database:
```sql
CREATE DATABASE weather;
```

2. Update `src/main/resources/application.properties` with your MySQL credentials:
```properties
spring.datasource.username=your_username
spring.datasource.password=your_password
```

3. Place your data file (`testset.csv` or `testset.xlsx`) in `src/main/resources/data/`

4. Run the application:
```bash
./mvnw spring-boot:run
```

The app will automatically load data on startup.

## API Endpoints

### 1. Basic Filter
Filter weather records by basic criteria.

**GET** `/api/weather/filter`

**Parameters:**
- `condition` - Weather condition (e.g., "Rain", "Clear")
- `date` - Specific date (YYYY-MM-DD)
- `month` - Month number (1-12)
- `year` - Year

**Example:**
```
GET /api/weather/filter?condition=Rain&year=2010&month=7
```

### 2. Advanced Filter (NEW)
Filter with multiple criteria including ranges and weather events.

**GET** `/api/weather/filter/advanced`

**Parameters:**
- `condition` - Weather condition
- `startDate` - Start date (YYYY-MM-DD)
- `endDate` - End date (YYYY-MM-DD)
- `year` - Year
- `month` - Month
- `minTemperature` - Minimum temperature
- `maxTemperature` - Maximum temperature
- `minHumidity` - Minimum humidity
- `maxHumidity` - Maximum humidity
- `fog` - Filter by fog (true/false)
- `rain` - Filter by rain (true/false)
- `snow` - Filter by snow (true/false)
- `thunder` - Filter by thunder (true/false)

**Example:**
```
GET /api/weather/filter/advanced?minTemperature=25&maxTemperature=35&rain=true&year=2015
```

### 3. Monthly Statistics
Get high, low, and median temperatures for each month of a year.

**GET** `/api/weather/stats`

**Parameters:**
- `year` - Year (required)

**Example:**
```
GET /api/weather/stats?year=2013
```

### 4. Aggregated Data
Group and summarize weather data.

**GET** `/api/weather/aggregate`

**Parameters:**
- `groupBy` - Group by: `year`, `month`, `day`, or `condition` (default: year)
- `condition` - Filter by weather condition
- `year` - Filter by year
- `month` - Filter by month

**Example:**
```
GET /api/weather/aggregate?groupBy=condition&year=2012
```

### 5. Reload Data
Force reload data from file without restarting.

**POST** `/api/admin/reload-data`

**Example:**
```
POST /api/admin/reload-data
```

## Response Format

All endpoints return JSON. Here are sample responses:

**Filter endpoints:**
```json
[
  {
    "recordDate": "2010-07-15",
    "weatherCondition": "Rain",
    "temperature": 28.5,
    "humidity": 85,
    "pressure": 1012.3
  }
]
```

**Monthly stats:**
```json
[
  {
    "month": 1,
    "maxTemp": 25.0,
    "minTemp": 8.5,
    "medianTemp": 16.2
  }
]
```

**Aggregated data:**
```json
{
  "2010": {
    "minTemp": 5.0,
    "maxTemp": 42.0,
    "avgTemp": 25.3,
    "avgHumidity": 65.5,
    "count": 365
  }
}
```

## Project Structure

```
src/main/java/com/example/weather/
├── controller/       # REST endpoints
├── service/          # Business logic
├── repository/       # Database access
├── entity/           # Database models
├── dto/              # API response objects
├── spec/             # Query specifications
└── prerun/           # Data loading utilities
```

## Notes

- All filter parameters are optional
- Date format: YYYY-MM-DD
- Temperature in Celsius
- Humidity as percentage (0-100)
- The app uses JPA Specifications for flexible, dynamic queries
- Data loads automatically on first startup if database is empty

## Default Port

The application runs on `http://localhost:8080`
