# Troubleshooting Guide

## Application Not Responding - Check These:

### 1. Is the application running?
Look at your terminal. You should see:
```
Started WeatherApplication in X.XXX seconds (JVM running for X.XXX)
```

If you see errors instead, read them carefully.

### 2. Common Errors:

**MySQL Connection Error:**
```
Error: Access denied for user 'root'@'localhost'
```
Fix: Check password in application.properties

**Database doesn't exist:**
```
Error: Unknown database 'weather'
```
Fix: Run in MySQL: `CREATE DATABASE weather;`

**Port already in use:**
```
Error: Port 8080 is already in use
```
Fix: Stop other application or change port (see below)

### 3. Change Port (if 8080 is busy)

Add this line to application.properties:
```
server.port=8081
```

Then use: `http://localhost:8081/api/weather/filter?year=2010`

### 4. Test if Application Started

In your running terminal, look for:
```
Tomcat started on port(s): 8080 (http)
```

This tells you which port to use.

### 5. Postman Setup

1. Method: GET
2. URL: http://localhost:8080/api/weather/filter
3. Params tab: Add key=year, value=2010
4. Click Send

OR just use the full URL:
```
http://localhost:8080/api/weather/filter?year=2010
```

### 6. Browser Test (Simplest)

Just paste in browser:
```
http://localhost:8080/api/weather/filter?year=2010
```

If you see "This site can't be reached" - the app is not running.

### 7. Check Console Output

Share the last 30 lines from your terminal where you ran mvnw.cmd spring-boot:run
