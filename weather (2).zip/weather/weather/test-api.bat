@echo off
echo Testing Weather API Endpoints...
echo.

echo 1. Testing Basic Filter (year=2010, month=1)
curl "http://localhost:8080/api/weather/filter?year=2010&month=1"
echo.
echo.

echo 2. Testing Advanced Filter (temperature 20-30, year=2015)
curl "http://localhost:8080/api/weather/filter/advanced?minTemperature=20&maxTemperature=30&year=2015"
echo.
echo.

echo 3. Testing Monthly Stats (year=2013)
curl "http://localhost:8080/api/weather/stats?year=2013"
echo.
echo.

echo 4. Testing Aggregation (by month, year=2012)
curl "http://localhost:8080/api/weather/aggregate?groupBy=month&year=2012"
echo.
echo.

echo All tests completed!
pause
